# Tindog
A tinder website made exclusively for Dogs.
# About TinDog
A home page website which provides details of the application to the end user like the description of the website, from where we can download the application, a section that displays the feedback from the clients and different plans and subscriptions.

# Tools Used
The main framework used in building the TinDog website is Bootstrap and its components like Carousel, Card, Buttons, Navbar etc. It also uses HTML5, CSS3 and Google Fonts and Font Awesome.

# Live Link 
Website link : https://hksirya.github.io/Tindog/
# Screenshots
![1](https://user-images.githubusercontent.com/104431269/171844785-30d75a47-c562-4ad1-a127-1116f367ceb8.png)
![2](https://user-images.githubusercontent.com/104431269/171844812-9030d7fb-970c-4e15-ab52-eff3e258e526.png)
![3](https://user-images.githubusercontent.com/104431269/171844820-604f4338-9254-465c-8abb-873a775b809c.png)
![4](https://user-images.githubusercontent.com/104431269/171844826-01636d2a-e836-493f-9503-7ff1c4d2c531.png)
![5](https://user-images.githubusercontent.com/104431269/171844834-5d3a2319-8073-48d9-b6cb-e07a944fdce1.png)
![6](https://user-images.githubusercontent.com/104431269/171844839-a7f397d8-e206-4577-b33b-16c2e06f1f03.png)
